import zad2

cir = zad2.circle()
tri = zad2.triangle()
sqr = zad2.square()

print(cir.area(), " ", cir.circuit())
print(tri.area(), " ", tri.circuit())
print(sqr.area(), " ", sqr.circuit())
